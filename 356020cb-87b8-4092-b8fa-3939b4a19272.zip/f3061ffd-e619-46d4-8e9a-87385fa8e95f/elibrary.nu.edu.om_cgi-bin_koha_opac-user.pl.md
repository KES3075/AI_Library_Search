---
url: "https://elibrary.nu.edu.om/cgi-bin/koha/opac-user.pl"
title: "Log in to your account › NU Libraries catalog"
---

Skip to main content

![](https://elibrary.nu.edu.om/opac-tmpl/bootstrap/images/BannerNU.png)

- [Home](https://elibrary.nu.edu.om/)
- [National University](https://nu.edu.om/)
- [MyNU](https://portal.nu.edu.om/login.aspx?ReturnUrl=%2fmember%2fdefault.aspx%3f_gl%3d1*6n7l1f*_ga*OTg0MzEwMjU2LjE3MjE3MzgxOTE.*_ga_KWF40KY50Z*MTcyMjE4MzQwMC4xMC4xLjE3MjIxODU1NDEuMC4wLjA.&_gl=1*6n7l1f*_ga*OTg0MzEwMjU2LjE3MjE3MzgxOTE.*_ga_KWF40KY50Z*MTcyMjE4MzQwMC4xMC4xLjE3MjIxODU1NDEuMC4wLjA/)
- [e-Journal Databases](https://elibrary.nu.edu.om/cgi-bin/koha/opac-user.pl#)
  - [Hindawi Publishing](https://www.hindawi.com/journals/)
  - [HighWire](https://portal.highwire.org/lists/browse.dtl/)
  - [PubMed Central](https://www.ncbi.nlm.nih.gov/)
  - [PLoS](https://plos.org/)
  - [Science Alert](https://scialert.net/journals.php/)
  - [Springer Open Access](https://www.springeropen.com/journals/)
- [e-Book Databases](https://elibrary.nu.edu.om/cgi-bin/koha/opac-user.pl#)
  - [Directory of Open Access Books (DOAB)](https://doabooks.org/)
  - [Open Library](https://www.oapen.org/home/)
  - [Project Gutenberg](https://www.gutenberg.org/)
  - [Rare Book Room](http://www.rarebookroom.org/)
- [Open Access Theses and Dissertations](https://oatd.org/)
- [Faculty Publication](https://elibrary.nu.edu.om/cgi-bin/koha/opac-user.pl#)
  - [HQ](https://elibrary.nu.edu.om/cgi-bin/koha/opac-user.pl#)
    - [Dr Ali Saud Ali Al Bimani](https://elibrary.nu.edu.om/cgi-bin/koha/opac-detail.pl?biblionumber=55036/)
  - [College of Medicine and Health Sciences](https://elibrary.nu.edu.om/cgi-bin/koha/opac-search.pl?idx=kw&q=faculty%20publication&sort_by=relevance&count=20&limit=holdingbranch:COMHS/)
  - [College of Pharmacy](https://elibrary.nu.edu.om/cgi-bin/koha/opac-search.pl?idx=kw&q=faculty%20publication&sort_by=relevance&count=20&limit=holdingbranch:COP/)
  - [College of Engineering](https://elibrary.nu.edu.om/cgi-bin/koha/opac-search.pl?idx=kw&q=faculty%20publication&sort_by=relevance&count=20&limit=holdingbranch:COE/)
  - [International Maritime College Oman](https://elibrary.nu.edu.om/cgi-bin/koha/opac-search.pl?idx=kw&q=faculty%20publication&sort_by=relevance&count=20&limit=holdingbranch:IMCO/)
- [Search Engines](https://elibrary.nu.edu.om/cgi-bin/koha/opac-user.pl#)
  - [Connecting Repositories (CORE)](https://core.ac.uk/)
  - [OAIster (WorldCat)](https://oaister.on.worldcat.org/discovery/)
  - [CiteSeerX](https://citeseerx.ist.psu.edu/)
  - [Bielefeld Academic Search Engine (BASE)](https://www.base-search.net/)
  - [Google Scholar](https://scholar.google.co.in/)
- [Contact Us](https://elibrary.nu.edu.om/cgi-bin/koha/opac-user.pl#)
  - [College of Engineering](https://nu.edu.om/engineering/library/about-library/)
  - [College of Medicine and Health Sciences](https://nu.edu.om/medicine/library/)
  - [International Maritime College Oman](https://nu.edu.om/maritime/library/)
  - [College of Pharmacy](https://nu.edu.om/pharmacy/library/)
  - [School of Foundation Studies](https://nu.edu.om/foundation/library/)

Search the catalog by:Library catalogTitleAuthorSubjectISBNISSNSeriesCall number

Search the catalog by keyword

All librariesCollege of Advanced TechnologyCollege of EngineeringCollege of Medicine and Health SciencesCollege of PharmacyInternational Maritime College OmanSchool of Foundation Studies

- [Advanced search](https://elibrary.nu.edu.om/cgi-bin/koha/opac-search.pl)
- [Browse by hierarchy](https://elibrary.nu.edu.om/cgi-bin/koha/opac-browser.pl)
- [Libraries](https://elibrary.nu.edu.om/cgi-bin/koha/opac-library.pl)

# Log in to your account

[Log in with MyNU](https://elibrary.nu.edu.om/api/v1/public/oauth/login/MicrosoftAzure/opac)

* * *

If you do not have an external account, but do have a local account, you can still log in:

Card number or username:

Password:

## Don't have a password yet?

If you don't have a password yet, stop by the circulation desk the next time you're in the library. We'll happily set one up for you.

## Don't have a library card?

If you don't have a library card, stop by your local library to sign up.

Copyright @ 2025, National University Libraries

Azaiba, Bousher, Muscat

Sultanate of Oman

[![web hit counter](https://counter.websiteout.com/compte.php?S=https%3A%2F%2Felibrary.nu.edu.om%2Fcgi-bin%2Fkoha%2Fopac-user.pl&C=7&D=1&N=0&M=0&clt=0&ca=)](https://www.websiteout.net/counter.php)